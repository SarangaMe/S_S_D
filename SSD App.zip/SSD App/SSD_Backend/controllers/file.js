
const uploadFile = async(req, res)=>{
	res.status(200).json("File updated");
}

module.exports = {uploadFile};
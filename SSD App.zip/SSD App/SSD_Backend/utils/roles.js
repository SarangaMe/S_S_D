module.exports = {
  ADMIN: 'admin',
  WORKER: 'worker',
  MANAGER: 'manager',
};

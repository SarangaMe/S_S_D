import React from "react";
import { Link } from "react-router-dom";

const RegisterUser = () => {
  return <div></div>;
};

export default RegisterUser;

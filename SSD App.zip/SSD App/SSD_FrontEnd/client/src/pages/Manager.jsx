import React from "react";
import Header from "../components/Header";
import ManagerHome from "./ManagerHome";
const Worker = () => {
  return (
    <div>
      <Header />
      <ManagerHome />
    </div>
  );
};

export default Worker;

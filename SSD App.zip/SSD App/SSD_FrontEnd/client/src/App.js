import NavigationRouter from './routes/NavigationRouter';

function App() {
  return <NavigationRouter />;
}

export default App;
